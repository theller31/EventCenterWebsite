# Event Center Website

This is a multi-page website for an event center, designed using HTML and CSS.

## Pages
- **Home:** Welcome message and hero banner.
- **Events:** Upcoming events with images and descriptions.
- **Menu:** Food menu in table format.
- **Location:** Venue address and map.
- **Contact Us:** Inquiry form with validation.

## Features
- Responsive layout with Flexbox.
- Navigation bar on all pages.
- Simple CSS styling for layout, tables, and hover effects.
